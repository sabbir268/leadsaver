<template>
  <v-app id="inspire">
    <v-navigation-drawer v-model="drawer" app >
      <v-list dense>
        <v-list-item link class="mb-3">
          <!-- <v-img src="https://rappleslimited.com/assets/img/logo-light.png"></v-img> -->
          <v-img src="https://khalidit.com/wp-content/uploads/2020/05/khalidit.png"></v-img>
        </v-list-item>
        <hr />

        <v-list-item to="/" link>
          <v-list-item-action>
            <v-icon>mdi-home</v-icon>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title>Home</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-item to="/sheets" link>
          <v-list-item-action>
            <v-icon>library_add</v-icon>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title>Sheets</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>

    <v-app-bar app color="indigo" dark>
      <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
      <v-toolbar-title>Application</v-toolbar-title>
    </v-app-bar>

    <v-main>
      <v-container fluid>
        <v-row align="center" justify="center">
          <v-col class="text-center">
            <router-view></router-view>
          </v-col>
        </v-row>
      </v-container>
    </v-main>
    <v-footer color="indigo" app>
      <span class="white--text">&copy; {{ new Date().getFullYear() }}</span>
    </v-footer>
  </v-app>
</template>

<script>
export default {
  props: {
    source: String
  },

  data: () => ({
    drawer: null
  })
};
</script>

<style>
a.v-list-item--link {
  text-decoration: none;
}
.w-100 {
  width: 100% !important;
}
</style>