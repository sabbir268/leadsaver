<template>
  <div>
    <LeadForm></LeadForm>
    <SheetData></SheetData>
  </div>
</template>

<script>
import LeadForm from "../components/LeadForm";
import SheetData from "../components/SheetData";

export default {
  components: {
    LeadForm,
    SheetData
  }
};
</script>

<style>
</style>